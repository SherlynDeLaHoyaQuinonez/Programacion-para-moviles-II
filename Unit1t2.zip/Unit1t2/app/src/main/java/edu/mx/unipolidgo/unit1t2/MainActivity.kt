package edu.mx.unipolidgo.unit1t2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn_red = findViewById<Button>(R.id.btn_red)
        val text = findViewById<TextView>(R.id.boxThree)

        val btn_yellow = findViewById<Button>(R.id.btn_yellow)
        val textChange = findViewById<TextView>(R.id.boxFour)

        val btn_green = findViewById<Button>(R.id.btn_green)
        val textChangeGreen = findViewById<TextView>(R.id.boxFive)

        btn_red.setOnClickListener {
            text.setBackgroundColor(ContextCompat.getColor(this, R.color.Red))


        }

        btn_yellow.setOnClickListener {
            textChange.setBackgroundColor(ContextCompat.getColor(this, R.color.yellow))
        }

        btn_green.setOnClickListener {
            textChangeGreen.setBackgroundColor(ContextCompat.getColor(this, R.color.Green))
        }

        text.setOnClickListener {
            text.setBackgroundColor(ContextCompat.getColor(this, R.color.Green2))
        }

        textChange.setOnClickListener {
            textChange.setBackgroundColor(ContextCompat.getColor(this, R.color.Green3))
        }

        textChangeGreen.setOnClickListener {
            textChangeGreen.setBackgroundColor(ContextCompat.getColor(this, R.color.Green2))
        }

    }
}